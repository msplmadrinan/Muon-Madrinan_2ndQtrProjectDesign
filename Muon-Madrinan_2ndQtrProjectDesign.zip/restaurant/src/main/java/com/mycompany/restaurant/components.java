/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.restaurant;

import java.util.ArrayList;

/**
 *
 * @author sophi
 */
public class components {
      private String ingredients;
      private String utensils;

    public static void main(String[] args) {
    
        System.out.println("List of ingredients:\n"
                + "10 porkchops\n"
                + "5 bowls of noodles\n"
                + "5 bowls of rice\n"
                + "10 shrimp\n"
                + "1 bottle of tonkatsu sauce (10 drizzles)\n"
                + "20 eggs\n"
                + "10 sides of coleslaw\n");
    
        System.out.println("List of utensils:\n"
                + "Spoon\n"
                + "Fork\n"
                + "Chopsticks");
        
    }
}
