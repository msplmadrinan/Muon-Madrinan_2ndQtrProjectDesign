/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.restaurant;

/**
 *
 * @author sophi
 */
public class customers {
        private String name;
        private String putOrder;
        private String orderUten;
        private double orderCost;
        private double change;
        
        private String putOrder() {

        }
        
        private double payOrder() {

        }
        
        private double getChange() {

            payOrder - orderCost = change;
    
        }
        
}
