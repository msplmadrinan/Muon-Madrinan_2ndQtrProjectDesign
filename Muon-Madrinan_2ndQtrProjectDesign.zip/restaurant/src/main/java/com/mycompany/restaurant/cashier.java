/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.restaurant;

/**
 *
 * @author sophi
 */
public class cashier {
        private double totalCash;
        private double orderCost;
        private double payOrder;
        private double change;
        
    double getTotal() {
    
    }
    
    double getCash() {
        
        payOrder + totalCash;
        
    }
    
    double giveChange() {
    
        payOrder - orderCost = change;
        
    }
        
}
