/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.restaurant;

import java.util.ArrayList;

/**
 *
 * @author sophi
 */
public class Restaurant {
        public String name;
        public boolean restoDoors;
        
    public static void main(String[] args) {
        
        public String setName() {
        
        }
        
        public boolean restoStatus() {

        }
    }
}
